#version 300 es
  precision highp float;

  out vec4 fragColor;

  uniform vec2 uResolution;
  uniform float uTime;
  uniform vec2 uBlockHalf;     // Half-size in aspect-corrected space
  uniform vec2 uTilt;          // Spring-smoothed pointer / gyro tilt (-1..1)
  uniform int uEffect;         // 0: Y2K CCD, 1: VHS, 2: CRT, 3: GameBoy, 4: Mac 1-Bit, 5: Digicam HUD, 6: Pure
  uniform int uBg;             // 0: Sky Aura, 1: Studio N8, 2: Terminal, 3: Android 16, 4: Swiss Graphic
  uniform float uBevelScale;

  // 6-slot ring buffer for single non-looping ripples: xy = local block pos, z = birth time, w = strength
  uniform vec4 uRipples[6];

  // Viscous stationary dent lens under held finger
  uniform vec2 uFingerPos;
  uniform float uFingerPress;

  float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
  }

  float sdRoundBox(vec2 p, vec2 b, float r) {
    vec2 q = abs(p) - b + r;
    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
  }

  // Procedural test backgrounds for black text legibility & refraction testing
  vec3 sampleBackground(vec2 p, int bgMode) {
    if (bgMode == 0) {
      // 0: Sky Aura (Reference 80637.jpg)
      vec3 topCol = vec3(0.87, 0.90, 0.94);
      vec3 midCyan = vec3(0.55, 0.82, 0.96);
      vec3 deepCobalt = vec3(0.20, 0.34, 0.92);
      vec3 violetGlow = vec3(0.56, 0.36, 0.95);

      float yNorm = clamp(p.y + 0.5, 0.0, 1.0);
      vec3 col = mix(deepCobalt, midCyan, smoothstep(0.18, 0.62, yNorm));
      col = mix(col, topCol, smoothstep(0.58, 0.95, yNorm));

      float aura = exp(-length((p - vec2(-0.04, -0.05)) * vec2(1.4, 2.2)) * 3.2);
      col = mix(col, violetGlow, aura * 0.65);

      float vignette = smoothstep(1.15, 0.25, length(p));
      return mix(vec3(0.84, 0.86, 0.90), col, 0.35 + 0.65 * vignette);
    }
    else if (bgMode == 1) {
      // 1: Studio N8 (Reference 80635.jpg — brushed aluminum & warm amber lens core)
      float grad = smoothstep(0.65, -0.55, p.y);
      vec3 studio = mix(vec3(0.76, 0.79, 0.83), vec3(0.32, 0.35, 0.40), grad);
      float amberCore = exp(-length(p - vec2(-0.06, 0.02)) * 5.2);
      studio += vec3(0.95, 0.36, 0.08) * amberCore * 0.85;
      float ring = smoothstep(0.012, 0.0, abs(length(p - vec2(-0.06, 0.02)) - 0.19));
      studio -= vec3(0.16) * ring;
      return studio;
    }
    else if (bgMode == 2) {
      // 2: Retro Terminal (Reference 80633.jpg — dark CRT console & amber phosphor lines)
      vec3 darkBase = vec3(0.11, 0.12, 0.13);
      vec2 grid = abs(fract(p * 14.0) - 0.5);
      float line = smoothstep(0.47, 0.50, max(grid.x, grid.y));
      vec3 col = darkBase + vec3(0.04, 0.05, 0.05) * line;
      float bar1 = smoothstep(0.012, 0.0, abs(p.y - 0.08)) * step(abs(p.x + 0.05), 0.16);
      float bar2 = smoothstep(0.010, 0.0, abs(p.y + 0.12)) * step(abs(p.x - 0.02), 0.18);
      col += vec3(0.85, 0.92, 0.95) * bar1 * 0.65;
      col += vec3(0.95, 0.48, 0.18) * bar2 * 0.75;
      return col;
    }
    else if (bgMode == 3) {
      // 3: Android 16 Material Mesh (Vibrant fluid blobs)
      vec2 q = p * 2.2;
      float w1 = sin(q.x * 2.1 + uTime * 0.25) * cos(q.y * 1.9 - uTime * 0.2);
      float w2 = cos(length(q - vec2(0.3, -0.2)) * 3.4 - uTime * 0.3);
      vec3 c1 = vec3(0.14, 0.82, 0.68);
      vec3 c2 = vec3(0.26, 0.42, 0.98);
      vec3 c3 = vec3(0.96, 0.44, 0.62);
      vec3 col = mix(c1, c2, 0.5 + 0.5 * w1);
      col = mix(col, c3, 0.35 + 0.35 * w2);
      return col;
    }
    else {
      // 4: Swiss Graphic Poster (Reference 80636.jpg / 80634.jpg)
      vec3 paper = vec3(0.86, 0.88, 0.90);
      float circle = smoothstep(0.245, 0.24, length(p - vec2(0.0, 0.03)));
      vec3 col = mix(paper, vec3(0.14, 0.16, 0.19), circle);
      float stripe = step(0.5, fract((p.x + p.y) * 18.0)) * smoothstep(0.18, 0.175, length(p - vec2(0.08, -0.14)));
      col = mix(col, vec3(0.94, 0.96, 0.98), stripe * 0.85);
      return col;
    }
  }

  // Bayer 4x4 threshold for Mac 1-Bit dithering
  float bayer4(vec2 frag) {
    ivec2 ip = ivec2(mod(frag, 4.0));
    int idx = ip.y * 4 + ip.x;
    const float m[16] = float[16](
       0.0/16.0,  8.0/16.0,  2.0/16.0, 10.0/16.0,
      12.0/16.0,  4.0/16.0, 14.0/16.0,  6.0/16.0,
       3.0/16.0, 11.0/16.0,  1.0/16.0,  9.0/16.0,
      15.0/16.0,  7.0/16.0, 13.0/16.0,  5.0/16.0
    );
    return m[idx];
  }

  // Apply chosen retro filter inside the acrylic glass volume
  vec3 applyRetroEffect(vec3 col, vec2 uvBlock, vec2 fragCoord, int mode) {
    if (mode == 0) {
      // 0: Y2K CCD (2003 compact digital camera sensor: RGGB Bayer micro-grid, highlight vertical smear, 8x8 DCT shimmer)
      ivec2 px = ivec2(mod(floor(fragCoord * 0.5), 2.0));
      vec3 bayerTint = vec3(0.96, 1.02, 1.05);
      if (px.x == 0 && px.y == 0) bayerTint = vec3(1.06, 0.98, 0.96);
      else if (px.x == 1 && px.y == 1) bayerTint = vec3(0.95, 0.98, 1.08);
      else bayerTint = vec3(0.97, 1.04, 0.98);

      // Vertical CCD highlight smear
      float luma = dot(col, vec3(0.299, 0.587, 0.114));
      float smear = smoothstep(0.68, 0.98, luma) * 0.11;
      col += vec3(0.75, 0.90, 1.0) * smear;

      // Subtle 8x8 JPEG/MPEG-4 block quantization feel + early CCD white balance
      vec2 blk = floor(fragCoord / 6.0);
      float grain = (hash12(blk + floor(uTime * 12.0)) - 0.5) * 0.032;
      col = col * bayerTint + grain;
      col = mix(vec3(luma), col, 1.14);
      return clamp(col, 0.0, 1.0);
    }
    else if (mode == 1) {
      // 1: VHS Hi-Fi (Y/C chroma bleeding + scanline jitter + tracking band)
      float scan = sin(fragCoord.y * 1.6) * 0.035;
      float trackY = fract(uTime * 0.14);
      float trackBand = smoothstep(0.035, 0.0, abs(uvBlock.y - trackY));
      float snow = hash12(vec2(fragCoord.x * 0.4, fragCoord.y + uTime * 60.0)) * trackBand * 0.35;
      float luma = dot(col, vec3(0.299, 0.587, 0.114));
      col = mix(vec3(luma), col, 0.85) + scan + snow;
      col.r += 0.035;
      col.b += 0.025;
      return clamp(col, 0.0, 1.0);
    }
    else if (mode == 2) {
      // 2: CRT Trinitron (RGB aperture grille triads + scanlines)
      float triad = mod(floor(fragCoord.x), 3.0);
      vec3 mask = triad < 0.5 ? vec3(1.16, 0.88, 0.88) : (triad < 1.5 ? vec3(0.88, 1.16, 0.88) : vec3(0.88, 0.88, 1.16));
      float scanline = 0.90 + 0.10 * sin(fragCoord.y * 3.14159);
      return clamp(col * mask * scanline * 1.05, 0.0, 1.0);
    }
    else if (mode == 3) {
      // 3: GameBoy LCD (4-tone DMG-01 olive-silver matrix with pixel grid)
      float luma = dot(col, vec3(0.299, 0.587, 0.114));
      float q = floor(clamp(luma, 0.0, 0.999) * 4.0) / 3.0;
      vec3 darkOlive = vec3(0.14, 0.21, 0.12);
      vec3 lightOlive = vec3(0.68, 0.75, 0.56);
      vec3 lcd = mix(darkOlive, lightOlive, q);
      vec2 cell = fract(fragCoord / 3.0);
      float grid = smoothstep(0.0, 0.14, cell.x) * smoothstep(0.0, 0.14, cell.y);
      return mix(lcd * 0.82, lcd, grid);
    }
    else if (mode == 4) {
      // 4: Mac 1-Bit (1984 Macintosh Bayer 4x4 ordered dithering, high readability)
      float luma = dot(col, vec3(0.299, 0.587, 0.114));
      float d = step(bayer4(floor(fragCoord * 0.5)), luma * 1.12);
      return mix(vec3(0.22, 0.24, 0.27), vec3(0.93, 0.95, 0.97), d);
    }
    else if (mode == 5) {
      // 5: Digicam HUD (Optical viewfinder brackets, crosshair, EV scale inside glass)
      vec2 ap = abs(uvBlock);
      // Corner AF brackets
      float bracketX = smoothstep(0.005, 0.0, abs(ap.x - 0.18)) * step(0.11, ap.y) * step(ap.y, 0.18);
      float bracketY = smoothstep(0.005, 0.0, abs(ap.y - 0.18)) * step(0.11, ap.x) * step(ap.x, 0.18);
      // Center crosshair
      float crossH = smoothstep(0.003, 0.0, abs(uvBlock.y)) * step(ap.x, 0.035) * step(0.01, ap.x);
      float crossV = smoothstep(0.003, 0.0, abs(uvBlock.x)) * step(ap.y, 0.035) * step(0.01, ap.y);
      float hud = clamp(bracketX + bracketY + crossH + crossV, 0.0, 1.0);
      vec3 hudCol = vec3(0.08, 0.10, 0.12);
      return mix(col, hudCol, hud * 0.65);
    }
    // 6: Pure PMMA Acrylic
    return col;
  }

  void main() {
    // Strictly centered coordinates from gl_FragCoord.xy
    float minDim = min(uResolution.x, uResolution.y);
    vec2 p = (gl_FragCoord.xy - 0.5 * uResolution) / minDim;

    // Subtle 3D tilt parallax shift for the block
    vec2 blockPos = p - uTilt * 0.016;
    float cornerR = 0.042;
    float d = sdRoundBox(blockPos, uBlockHalf, cornerR);

    // Base background outside the acrylic block
    vec3 bgCol = sampleBackground(p, uBg);

    // Soft cast drop shadow beneath the floating acrylic slab
    float shadowD = sdRoundBox(blockPos - vec2(0.012, -0.022) - uTilt * 0.012, uBlockHalf, cornerR);
    float shadow = smoothstep(0.075, -0.01, shadowD) * 0.24;
    bgCol *= (1.0 - shadow);

    if (d > 0.002) {
      // Subtle ambient outer rim caustic
      float outerGlow = exp(-d * 65.0) * 0.14;
      fragColor = vec4(bgCol + vec3(outerGlow), 1.0);
      return;
    }

    // Inside the PMMA Acrylic Block:
    // 1. Analytical 45° chamfered bevel normal
    float bevelWidth = 0.044 * uBevelScale;
    float edgeZone = smoothstep(-bevelWidth, 0.0, d);
    vec2 eps = vec2(0.0015, 0.0);
    vec2 bevelGrad = normalize(vec2(
      sdRoundBox(blockPos + eps.xy, uBlockHalf, cornerR) - sdRoundBox(blockPos - eps.xy, uBlockHalf, cornerR),
      sdRoundBox(blockPos + eps.yx, uBlockHalf, cornerR) - sdRoundBox(blockPos - eps.yx, uBlockHalf, cornerR)
    ) + 1e-5);

    // 2. Non-looping ring-buffer ripples (6 slots)
    vec2 waveOffset = vec2(0.0);
    float waveHighlight = 0.0;
    for (int i = 0; i < 6; i++) {
      vec4 rip = uRipples[i];
      float age = uTime - rip.z;
      if (rip.w > 0.001 && age >= 0.0 && age < 1.8) {
        vec2 diff = blockPos - rip.xy;
        float dist = length(diff);
        float radius = age * 0.42;
        float ring = exp(-pow((dist - radius) * 26.0, 2.0));
        float decay = exp(-age * 2.9) * rip.w;
        float w = sin((dist - radius) * 75.0) * ring * decay;
        vec2 dir = normalize(diff + 1e-5);
        waveOffset += dir * w * 0.018;
        waveHighlight += w * 0.22;
      }
    }

    // 3. Viscous optical dent lens under stationary held finger
    vec2 fingerDiff = blockPos - uFingerPos;
    float fingerDist = length(fingerDiff);
    float lensProfile = exp(-fingerDist * fingerDist * 26.0) * uFingerPress;
    vec2 lensOffset = fingerDiff * lensProfile * 0.22;
    float lensRim = exp(-pow((fingerDist - 0.11) * 24.0, 2.0)) * uFingerPress * 0.18;

    // 4. Snell's law thickness refraction + RGB chromatic dispersion on chamfered edges
    vec2 thicknessParallax = uTilt * 0.028;
    vec2 refractBase = bevelGrad * pow(edgeZone, 1.65) * 0.052 * uBevelScale
                     + thicknessParallax
                     + waveOffset
                     + lensOffset;

    float disp = (0.009 * pow(edgeZone, 1.4) * uBevelScale) + (lensProfile * 0.006);
    float colR = sampleBackground(p - refractBase * (1.0 + disp * 14.0), uBg).r;
    float colG = sampleBackground(p - refractBase, uBg).g;
    float colB = sampleBackground(p - refractBase * (1.0 - disp * 14.0), uBg).b;
    vec3 glassCol = vec3(colR, colG, colB);

    // 5. Internal milky frosted diffusion so #090A0C black text is always crisp & legible
    float lumaBg = dot(glassCol, vec3(0.299, 0.587, 0.114));
    float adaptiveFrost = mix(0.56, 0.30, smoothstep(0.2, 0.85, lumaBg));
    vec3 milkyTint = vec3(0.93, 0.95, 0.98);
    glassCol = mix(glassCol, milkyTint, adaptiveFrost);

    // Subtle PMMA cast acrylic cyan/emerald tint in thick chamfered corners (like 80636.jpg & 80637.jpg)
    float cornerFactor = smoothstep(0.08, 0.32, length(max(abs(blockPos) - (uBlockHalf - 0.09), 0.0)));
    vec3 pmmaTint = vec3(0.06, 0.22, 0.20) * pow(edgeZone, 1.8) * (0.45 + 0.55 * cornerFactor);
    glassCol += pmmaTint;

    // 6. Apply selected retro sensor/display effect
    vec2 localNorm = blockPos / (uBlockHalf * 2.0);
    glassCol = applyRetroEffect(glassCol, localNorm, gl_FragCoord.xy, uEffect);

    // 7. Studio directional specular highlights + chamfer crisp inner/outer edge lines
    vec2 lightDir = normalize(vec2(-0.58, 0.81) + uTilt * 0.45);
    float specBevel = pow(max(0.0, dot(bevelGrad, lightDir)), 5.0) * edgeZone;
    float backRim = pow(max(0.0, dot(bevelGrad, -lightDir)), 4.0) * edgeZone * 0.45;

    // Diagonal studio softbox sheen across the front face
    float sheen = smoothstep(0.32, -0.28, dot(blockPos, vec2(0.65, -0.75)) + uTilt.x * 0.12) * 0.09;

    // Crisp razor chamfer edge line
    float innerChamferLine = smoothstep(0.0028, 0.0, abs(d + bevelWidth * 0.85)) * 0.32;
    float outerRimLine = smoothstep(0.0022, 0.0, abs(d + 0.0012)) * 0.65;

    // Subtle micro-dust / tactile surface texture
    float microGrain = (hash12(floor(gl_FragCoord.xy)) - 0.5) * 0.012;

    glassCol += vec3(specBevel * 0.62 + backRim * 0.35 + sheen + innerChamferLine + outerRimLine + waveHighlight + lensRim + microGrain);

    // Anti-aliased edge blend with background
    float alpha = smoothstep(0.0015, -0.0015, d);
    vec3 finalCol = mix(bgCol, clamp(glassCol, 0.0, 1.0), alpha);

    fragColor = vec4(finalCol, 1.0);
  }
