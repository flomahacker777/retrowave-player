package com.retrowave.player.ui

import android.content.Context
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.util.Log
import android.view.MotionEvent
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets
import java.util.Locale
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max
import kotlin.math.min

/**
 * Runs the user's supplied WebGL2 PMMA acrylic shaders directly on Android's OpenGL ES 3.0.
 * The vertex and fragment shader files are extracted verbatim from liquid.txt.
 */
class PmmaShaderView(context: Context) : GLSurfaceView(context) {
    private val pmmaRenderer = PmmaRenderer(context.applicationContext)

    init {
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 8, 0, 0)
        setRenderer(pmmaRenderer)
        renderMode = RENDERMODE_CONTINUOUSLY
        preserveEGLContextOnPause = true
        isFocusable = true
        isFocusableInTouchMode = true
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        pmmaRenderer.onTouch(event)
        return true
    }
}

private class PmmaRenderer(private val appContext: Context) : GLSurfaceView.Renderer {
    private val tag = "Retrowave.PMMA"
    private var program = 0
    private var vao = 0
    private var ready = false
    private var surfaceWidth = 1
    private var surfaceHeight = 1
    private var startNanos = 0L

    private var uResolution = -1
    private var uTime = -1
    private var uBlockHalf = -1
    private var uTilt = -1
    private var uEffect = -1
    private var uBg = -1
    private var uBevelScale = -1
    private var uRipples = -1
    private var uFingerPos = -1
    private var uFingerPress = -1

    private val lock = Any()
    private var targetTiltX = 0f
    private var targetTiltY = 0f
    private var tiltX = 0f
    private var tiltY = 0f
    private var fingerX = 0f
    private var fingerY = 0f
    private var targetFingerPress = 0f
    private var fingerPress = 0f
    private var lastRippleX = 0f
    private var lastRippleY = 0f
    private var lastRippleNanos = 0L
    private val rippleData = FloatArray(6 * 4)
    private var rippleCursor = 0

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.045f, 0.055f, 0.065f, 1f)
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        GLES30.glDisable(GLES30.GL_CULL_FACE)

        val vertexSource = readAsset("shaders/liquid_vertex.glsl")
        val fragmentSource = readAsset("shaders/liquid_fragment.glsl")
        val vertex = compile(GLES30.GL_VERTEX_SHADER, vertexSource, "vertex")
        val fragment = compile(GLES30.GL_FRAGMENT_SHADER, fragmentSource, "fragment")
        if (vertex == 0 || fragment == 0) {
            ready = false
            Log.e(tag, "The provided PMMA shader did not compile; see the compiler log above")
            return
        }

        program = GLES30.glCreateProgram()
        GLES30.glAttachShader(program, vertex)
        GLES30.glAttachShader(program, fragment)
        GLES30.glLinkProgram(program)
        val linkStatus = IntArray(1)
        GLES30.glGetProgramiv(program, GLES30.GL_LINK_STATUS, linkStatus, 0)
        if (linkStatus[0] == 0) {
            Log.e(tag, "Program link failed: ${GLES30.glGetProgramInfoLog(program)}")
            GLES30.glDeleteProgram(program)
            program = 0
            ready = false
            return
        }

        GLES30.glDeleteShader(vertex)
        GLES30.glDeleteShader(fragment)
        GLES30.glUseProgram(program)

        val vaoIds = IntArray(1)
        GLES30.glGenVertexArrays(1, vaoIds, 0)
        vao = vaoIds[0]
        GLES30.glBindVertexArray(vao)

        uResolution = uniform("uResolution")
        uTime = uniform("uTime")
        uBlockHalf = uniform("uBlockHalf")
        uTilt = uniform("uTilt")
        uEffect = uniform("uEffect")
        uBg = uniform("uBg")
        uBevelScale = uniform("uBevelScale")
        uRipples = uniform("uRipples[0]")
        uFingerPos = uniform("uFingerPos")
        uFingerPress = uniform("uFingerPress")

        ready = true
        startNanos = System.nanoTime()
        Log.i(tag, "Supplied WebGL2 PMMA fragment shader is running on GLES 3.0")
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        surfaceWidth = max(1, width)
        surfaceHeight = max(1, height)
        GLES30.glViewport(0, 0, surfaceWidth, surfaceHeight)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
        if (!ready || program == 0) return

        val now = System.nanoTime()
        val timeSeconds = (now - startNanos).coerceAtLeast(0L) / 1_000_000_000f
        synchronized(lock) {
            tiltX += (targetTiltX - tiltX) * 0.14f
            tiltY += (targetTiltY - tiltY) * 0.14f
            fingerPress += (targetFingerPress - fingerPress) * 0.16f

            GLES30.glUseProgram(program)
            GLES30.glBindVertexArray(vao)
            GLES30.glUniform2f(uResolution, surfaceWidth.toFloat(), surfaceHeight.toFloat())
            GLES30.glUniform1f(uTime, timeSeconds)

            val minDim = min(surfaceWidth, surfaceHeight).toFloat().coerceAtLeast(1f)
            // The acrylic slab fills almost the entire Compose panel while retaining a fine edge margin.
            GLES30.glUniform2f(
                uBlockHalf,
                surfaceWidth / minDim * 0.465f,
                surfaceHeight / minDim * 0.465f
            )
            GLES30.glUniform2f(uTilt, tiltX, tiltY)
            GLES30.glUniform1i(uEffect, 6) // Pure PMMA, no extra display-filter overlay.
            GLES30.glUniform1i(uBg, 1)     // Studio N8: brushed metal with a warm amber optical core.
            GLES30.glUniform1f(uBevelScale, 1.0f)
            GLES30.glUniform4fv(uRipples, 6, rippleData, 0)
            GLES30.glUniform2f(uFingerPos, fingerX, fingerY)
            GLES30.glUniform1f(uFingerPress, fingerPress)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
        }
    }

    fun onTouch(event: MotionEvent) {
        val minDim = min(surfaceWidth, surfaceHeight).toFloat().coerceAtLeast(1f)
        val x = (event.x - surfaceWidth * 0.5f) / minDim
        val y = (surfaceHeight * 0.5f - event.y) / minDim
        val now = System.nanoTime()
        synchronized(lock) {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    fingerX = x
                    fingerY = y
                    targetFingerPress = 1f
                    targetTiltX = (x / 0.28f).coerceIn(-1f, 1f)
                    targetTiltY = (y / 0.36f).coerceIn(-1f, 1f)
                    spawnRipple(x, y, now, 1f)
                }
                MotionEvent.ACTION_MOVE -> {
                    fingerX = x
                    fingerY = y
                    targetTiltX = (x / 0.28f).coerceIn(-1f, 1f)
                    targetTiltY = (y / 0.36f).coerceIn(-1f, 1f)
                    val moved = kotlin.math.hypot((x - lastRippleX).toDouble(), (y - lastRippleY).toDouble()).toFloat()
                    if (moved > 0.055f && now - lastRippleNanos > 95_000_000L) {
                        spawnRipple(x, y, now, 0.75f)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    targetFingerPress = 0f
                    targetTiltX = 0f
                    targetTiltY = 0f
                }
            }
        }
    }

    private fun spawnRipple(x: Float, y: Float, nowNanos: Long, strength: Float) {
        val birthTime = (nowNanos - startNanos).coerceAtLeast(0L) / 1_000_000_000f
        val i = rippleCursor * 4
        rippleData[i] = x
        rippleData[i + 1] = y
        rippleData[i + 2] = birthTime
        rippleData[i + 3] = strength
        rippleCursor = (rippleCursor + 1) % 6
        lastRippleX = x
        lastRippleY = y
        lastRippleNanos = nowNanos
    }

    private fun readAsset(path: String): String =
        appContext.assets.open(path).use { input ->
            BufferedReader(InputStreamReader(input, StandardCharsets.UTF_8)).readText()
        }

    private fun compile(type: Int, source: String, name: String): Int {
        val shader = GLES30.glCreateShader(type)
        GLES30.glShaderSource(shader, source)
        GLES30.glCompileShader(shader)
        val status = IntArray(1)
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            Log.e(tag, String.format(Locale.US, "%s compile failed:\n%s", name, GLES30.glGetShaderInfoLog(shader)))
            GLES30.glDeleteShader(shader)
            return 0
        }
        return shader
    }

    private fun uniform(name: String): Int {
        val location = GLES30.glGetUniformLocation(program, name)
        if (location < 0) Log.w(tag, "Uniform not found or optimized out: $name")
        return location
    }
}
